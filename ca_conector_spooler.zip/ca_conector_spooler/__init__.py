# -*- coding: utf-8 -*-
#################################################################################################
#
#    Interfaz Odoo con Asistente Fiscal Super Spooler
#
#    Febrero 2022
#    Autor: Carlos Alfonzo (calfonzodaly@gmail.com)
#
#    Interfaz para impresion en impresoras fiscales, a traves del Asistete Fiscal Super Spooler
#
#
##################################################################################################

from . import models