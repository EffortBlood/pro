# -*- coding: utf-8 -*-
# Part of Softhealer Technologies

{
    "name": "All In One Lock Price | Sale Order Lock Price | Purchase Order Lock Price | Invoice Lock Price | Lock Sale Price | Lock Cost Price",
    "author": "Softhealer Technologies",
    "website": "https://www.softhealer.com",
    "support": "support@softhealer.com",
    "category": "Productivity",
    "summary": "Lock Product Price Lock Cost Price Lock Sales Price Lock Unit Price Lock Product Unit Price Lock Sale Order Price Lock Purchase Order Price Lock Invoice Lock Change Price Restrict To Change Product Price Restrict Product Price Update Odoo",
    "description": """This module helps to lock product price in the product, sale order, purchase order & invoice. Once price is define in the product, User will not allow to change a price in the product, sale order, purchase order & invoice. Who has access rights to change price that users only can change prices in the product, sale order, purchase order & invoice.""",
    "license": "OPL-1",
    "version": "16.0.1",
    "depends": ["sale_management", "purchase", "sale_purchase"],
    "data": [
        'security/sh_lock_price_groups.xml',

        'views/account_move_views.xml',
        'views/product_views.xml',
        'views/purchase_order_views.xml',
        'views/sale_order_views.xml',
    ],

    "auto_install": False,
    "installable": True,
    "application": True,
    "images": ["static/description/background.png", ],
    "price": 30,
    "currency": "EUR",
}
