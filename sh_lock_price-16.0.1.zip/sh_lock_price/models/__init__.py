# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from . import account_move
from . import product_template
from . import purchase_order
from . import sale_order
