# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from odoo import api, fields, models

class ShLockPriceSaleOrder(models.Model):
    _inherit = "sale.order"

    """
        INHERITED BY SOFTHEALER TECHNOLOGIES.
    """

    @api.model
    def default_is_sh_lock_price_change_unit_price(self):
        return self.user_has_groups(
            'sh_lock_price.change_unit_price')

    is_sh_lock_price_change_unit_price = fields.Boolean(
        'Change Unit Price', default=default_is_sh_lock_price_change_unit_price, compute='_compute_is_sh_lock_price_change_unit_price')

    def _compute_is_sh_lock_price_change_unit_price(self):
        for order in self:
            order.is_sh_lock_price_change_unit_price = self.user_has_groups(
                'sh_lock_price.change_unit_price')
